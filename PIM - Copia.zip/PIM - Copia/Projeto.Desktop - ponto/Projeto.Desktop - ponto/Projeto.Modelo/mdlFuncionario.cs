﻿using System;

namespace Projeto.Modelo
{
    public class Funcionario
    {

        public int IdFuncionario { get; set; }
        public string Nome { get; set; }
        public string Matricula { get; set; }
        public string CPF { get; set; }
        public string Endereco { get; set; }
        public string Email { get; set; }
        public string Cargo { get; set; }
        public DateTime DataAdmissao { get; set; }
        public decimal SalarioBruto { get; set; }
        public string Telefone { get; set; }
        public int? IdEmpresa { get; set; }
        public int? MesReferencia { get; set; }
    }
}