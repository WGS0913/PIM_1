﻿using Projeto.Modelo;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Projeto.Controle
{
    public class ctlUsuario
    {
        public string conexaoSql = @"Data Source=MSV_L09M50\UNIP;Initial Catalog=POOII;Integrated Security=True";

        public bool incluirAluno(mdlUsuario _mdlUsuario)
        {
            SqlConnection conexaodb = new SqlConnection(conexaoSql);
            try
            {
                conexaodb.Open();

                string query = "INSERT INTO TB_Usuario (nome, rg, cpf) VALUES (@Nome, @Rg, @Cpf)";
                SqlCommand cmd = new SqlCommand(query, conexaodb);

                var pmtNome = cmd.CreateParameter();
                pmtNome.ParameterName = "@Nome";
                pmtNome.DbType = DbType.String;
                pmtNome.Value = _mdlUsuario.nome;
                cmd.Parameters.Add(pmtNome);

                var pmtRg = cmd.CreateParameter();
                pmtRg.ParameterName = "@Rg";
                pmtRg.DbType = DbType.String;
                pmtRg.Value = _mdlUsuario.rg;
                cmd.Parameters.Add(pmtRg);

                var pmtCpf = cmd.CreateParameter();
                pmtCpf.ParameterName = "@Cpf";
                pmtCpf.DbType = DbType.String;
                pmtCpf.Value = _mdlUsuario.cpf;
                cmd.Parameters.Add(pmtCpf);

                if (cmd.ExecuteNonQuery() > 0)
                {
                    conexaodb.Close();
                    return true;
                }
                else
                {
                    conexaodb.Close();
                    return false;
                }
            }
            catch (Exception)
            {
                conexaodb.Close();
                throw;
            }
        }
    }
}


