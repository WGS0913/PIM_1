﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Projeto.Modelo;

namespace Projeto.Controle
{
    public class CtlFuncionario
    {
        private const string ConnectionString = "Data Source=DESKTOP-30FVRF9\\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True";

        public List<Projeto.Modelo.Funcionario> ObterFuncionariosPorNome(string nome)
        {
            List<Projeto.Modelo.Funcionario> funcionariosEncontrados = new List<Projeto.Modelo.Funcionario>();

            string sqlQuery = "SELECT [idFuncionario], [nome], [matricula], [cpf], [endereco], [email], [cargo], [data_admissao], [salario_bruto], [telefone], [idEmpresa], [mesReferencia] " +
                              "FROM [dbo].[Funcionarios] " +
                              "WHERE [nome] = @Nome";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(sqlQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Nome", nome);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Projeto.Modelo.Funcionario funcionario = new Projeto.Modelo.Funcionario
                            {
                                IdFuncionario = (int)reader["idFuncionario"],
                                Nome = (string)reader["nome"],
                                Matricula = (string)reader["matricula"],
                                CPF = (string)reader["cpf"],
                                Endereco = (string)reader["endereco"],
                                Email = (string)reader["email"],
                                Cargo = (string)reader["cargo"],
                                DataAdmissao = (DateTime)reader["data_admissao"],
                                SalarioBruto = (decimal)reader["salario_bruto"],
                                Telefone = (string)reader["telefone"],
                                IdEmpresa = reader["idEmpresa"] != DBNull.Value ? (int)reader["idEmpresa"] : (int?)null,
                                MesReferencia = reader["mesReferencia"] != DBNull.Value ? (int)reader["mesReferencia"] : (int?)null
                            };

                            funcionariosEncontrados.Add(funcionario);
                        }
                    }
                }
            }

            return funcionariosEncontrados;
        }

        public void InserirFuncionario(Funcionario funcionario)
        {
            string sqlQuery = "INSERT INTO Funcionarios (nome, matricula, cpf, endereco, email, cargo, data_admissao, salario_bruto, telefone, idEmpresa, mesReferencia) " +
                             "VALUES (@Nome, @Matricula, @CPF, @Endereco, @Email, @Cargo, @DataAdmissao, @SalarioBruto, @Telefone, @IdEmpresa, @MesReferencia)";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(sqlQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Nome", funcionario.Nome);
                    cmd.Parameters.AddWithValue("@Matricula", funcionario.Matricula);
                    cmd.Parameters.AddWithValue("@CPF", funcionario.CPF);
                    cmd.Parameters.AddWithValue("@Endereco", funcionario.Endereco);
                    cmd.Parameters.AddWithValue("@Email", funcionario.Email);
                    cmd.Parameters.AddWithValue("@Cargo", funcionario.Cargo);
                    cmd.Parameters.AddWithValue("@DataAdmissao", funcionario.DataAdmissao);
                    cmd.Parameters.AddWithValue("@SalarioBruto", funcionario.SalarioBruto);
                    cmd.Parameters.AddWithValue("@Telefone", funcionario.Telefone);
                    cmd.Parameters.AddWithValue("@IdEmpresa", funcionario.IdEmpresa ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@MesReferencia", funcionario.MesReferencia ?? (object)DBNull.Value);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void AtualizarFuncionario(Funcionario funcionario)
        {
            string sqlQuery = "UPDATE Funcionarios SET nome = @Nome, cpf = @CPF, endereco = @Endereco, email = @Email, " +
                             "cargo = @Cargo, data_admissao = @DataAdmissao, salario_bruto = @SalarioBruto, " +
                             "telefone = @Telefone, idEmpresa = @IdEmpresa, mesReferencia = @MesReferencia " +
                             "WHERE matricula = @Matricula";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(sqlQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Nome", funcionario.Nome);
                    cmd.Parameters.AddWithValue("@CPF", funcionario.CPF);
                    cmd.Parameters.AddWithValue("@Endereco", funcionario.Endereco);
                    cmd.Parameters.AddWithValue("@Email", funcionario.Email);
                    cmd.Parameters.AddWithValue("@Cargo", funcionario.Cargo);
                    cmd.Parameters.AddWithValue("@DataAdmissao", funcionario.DataAdmissao);
                    cmd.Parameters.AddWithValue("@SalarioBruto", funcionario.SalarioBruto);
                    cmd.Parameters.AddWithValue("@Telefone", funcionario.Telefone);
                    cmd.Parameters.AddWithValue("@IdEmpresa", funcionario.IdEmpresa ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@MesReferencia", funcionario.MesReferencia ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Matricula", funcionario.Matricula);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<Projeto.Modelo.Funcionario> ObterTodosOsFuncionarios()
        {
            List<Projeto.Modelo.Funcionario> funcionarios = new List<Projeto.Modelo.Funcionario>();

            string query = "SELECT * FROM Funcionarios";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Projeto.Modelo.Funcionario funcionario = new Projeto.Modelo.Funcionario
                            {
                                IdFuncionario = (int)reader["idFuncionario"],
                                Nome = (string)reader["nome"],
                                Matricula = (string)reader["matricula"],
                                CPF = (string)reader["cpf"],
                                Endereco = (string)reader["endereco"],
                                Email = (string)reader["email"],
                                Cargo = (string)reader["cargo"],
                                DataAdmissao = (DateTime)reader["data_admissao"],
                                SalarioBruto = (decimal)reader["salario_bruto"],
                                Telefone = (string)reader["telefone"],
                                IdEmpresa = reader["idEmpresa"] != DBNull.Value ? (int)reader["idEmpresa"] : (int?)null,
                                MesReferencia = reader["mesReferencia"] != DBNull.Value ? (int)reader["mesReferencia"] : (int?)null
                            };

                            funcionarios.Add(funcionario);
                        }
                    }
                }
            }

            return funcionarios;
        }

        public void ExcluirFuncionario(string matricula)
        {
            string sqlQuery = "DELETE FROM Funcionarios WHERE matricula = @Matricula";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(sqlQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@Matricula", matricula);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
