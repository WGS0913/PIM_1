﻿using Projeto.Controle;
using Projeto.Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projeto.Desktop.Funcionario
{
    public partial class frmIncluir : Form
    {
        public frmIncluir()
        {
            InitializeComponent();
        }

        private void ManipularDados()
        {
            btnAlterar.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnNovo.Enabled = false;
            btnGravar.Enabled = false;
            txtCargo.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtSenha.Enabled = true;
            txtCPF.Enabled = true;
            txtNome.Enabled = true;
            txtAdmissao.Enabled = true;
            txtSalario.Enabled = true;
        }

        private void DesabilitarCampos()
        {
            txtCargo.Enabled = false;
            txtEmail.Enabled = false;
            txtEndereco.Enabled = false;
            txtSenha.Enabled = false;
            txtCPF.Enabled = false;
            txtNome.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = false;
            btnGravar.Enabled = false;
            txtAdmissao.Enabled = false;
            btnNovo.Enabled = true;
            txtSalario.Enabled = false;
            txtMesReferencia.Enabled = false;
            txtTelefone.Enabled = false;
            txtNome.Focus();
        }

        private void HabilitarCampos()
        {
            txtCargo.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtSenha.Enabled = true;
            txtCPF.Enabled = true;
            txtNome.Enabled = true;
            txtSalario.Enabled = true;
            btnGravar.Enabled = true;
            btnCancelar.Enabled = true;
            txtAdmissao.Enabled = true;
            txtMesReferencia.Enabled = true;
            txtTelefone.Enabled = true;
            btnNovo.Enabled = false;
            txtNome.Focus();
            txtBusca.Text = "";
            dgvFunc.DataSource = null;
        }

        private void LimparCampos()
        {
            txtCargo.Clear();
            txtEmail.Clear();
            txtEndereco.Clear();
            txtSenha.Clear();
            txtCPF.Clear();
            txtNome.Clear();
            txtAdmissao.Clear();
            txtMesReferencia.Clear();
            txtNome.Focus();
            txtBusca.Clear();
            txtSalario.Clear();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            HabilitarCampos();
            LimparCampos();
        }

        private void frmIncluir_Load(object sender, EventArgs e)
        {
            DesabilitarCampos();
            LimparCampos();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DesabilitarCampos();
            LimparCampos();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtIdEmpresa.Text, out int idEmpresaSelecionada))
            {
                if (EmpresaExiste(idEmpresaSelecionada))
                {
                    Projeto.Modelo.Funcionario novoFuncionario = new Projeto.Modelo.Funcionario
                    {
                        Nome = txtNome.Text,
                        Matricula = txtMatricula.Text,
                        CPF = txtCPF.Text,
                        Endereco = txtEndereco.Text,
                        Email = txtEmail.Text,
                        Cargo = txtCargo.Text,
                        DataAdmissao = DateTime.Parse(txtAdmissao.Text),
                        SalarioBruto = Decimal.Parse(txtSalario.Text),
                        Telefone = txtTelefone.Text,
                        MesReferencia = !string.IsNullOrEmpty(txtMesReferencia.Text) ? int.Parse(txtMesReferencia.Text) : (int?)null,
                        IdEmpresa = idEmpresaSelecionada
                    };

                    CtlFuncionario controleFuncionario = new CtlFuncionario();
                    controleFuncionario.InserirFuncionario(novoFuncionario);

                    DesabilitarCampos();
                    LimparCampos();
                    AtualizarDataGridView(dgvFunc);
                }
                else
                {
                    MessageBox.Show("A empresa com o Id especificado não existe no banco de dados.", "Erro");
                }
            }
            else
            {
                MessageBox.Show("O Id da empresa inserido não é válido. Insira um número válido.", "Erro");
            }
        }

        private bool EmpresaExiste(int idEmpresa)
        {
            string connectionString = "Data Source=DESKTOP-30FVRF9\\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True";
            string query = "SELECT COUNT(*) FROM Empresa WHERE IdEmpresa = @IdEmpresa";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@IdEmpresa", idEmpresa);

                    int count = (int)cmd.ExecuteScalar();

                    return count > 0;
                }
            }
        }

        private void AtualizarDataGridView(DataGridView dgv)
        {
            if (dgv != null)
            {
                CtlFuncionario controleFuncionario = new CtlFuncionario();
                List<Projeto.Modelo.Funcionario> funcionariosAtualizados = controleFuncionario.ObterTodosOsFuncionarios();

                dgv.Rows.Clear();

                foreach (var funcionario in funcionariosAtualizados)
                {
                    dgv.Rows.Add(
                        funcionario.IdFuncionario,
                        funcionario.Nome,
                        funcionario.Matricula,
                        funcionario.CPF,
                        funcionario.Endereco,
                        funcionario.Email,
                        funcionario.Cargo,
                        funcionario.DataAdmissao,
                        funcionario.SalarioBruto,
                        funcionario.Telefone,
                        funcionario.IdEmpresa,
                        funcionario.MesReferencia
                    );
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dgvFunc.SelectedRows.Count > 0)
            {
                int idFuncionarioParaExcluir = (int)dgvFunc.SelectedRows[0].Cells["IdFuncionario"].Value;

                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este funcionário?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    CtlFuncionario controleFuncionario = new CtlFuncionario();
                    string matriculaParaExcluir = idFuncionarioParaExcluir.ToString(); // Converte para string
                    controleFuncionario.ExcluirFuncionario(matriculaParaExcluir);
                    AtualizarDataGridView(dgvFunc);
                }

            }
            else
            {
                MessageBox.Show("Selecione um funcionário para excluir.", "Aviso");
            }
        }

        private void txtBusca_TextChanged(object sender, EventArgs e)
        {
            string nomePesquisado = txtBusca.Text;
            List<Projeto.Modelo.Funcionario> funcionariosEncontrados = ObterFuncionariosPorNome(nomePesquisado);

            // Atualiza o DataGridView com os resultados da pesquisa
            dgvFunc.Rows.Clear();
            foreach (var funcionario in funcionariosEncontrados)
            {
                dgvFunc.Rows.Add(
                    funcionario.IdFuncionario,
                    funcionario.Nome,
                    funcionario.Matricula,
                    funcionario.CPF,
                    funcionario.Endereco,
                    funcionario.Email,
                    funcionario.Cargo,
                    funcionario.DataAdmissao,
                    funcionario.SalarioBruto,
                    funcionario.Telefone,
                    funcionario.IdEmpresa,
                    funcionario.MesReferencia
                );
            }
        }


        private List<Projeto.Modelo.Funcionario> ObterTodosOsFuncionarios()
        {
            List<Projeto.Modelo.Funcionario> funcionarios = new List<Projeto.Modelo.Funcionario>();
            string connectionString = "Data Source=DESKTOP-30FVRF9\\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True";
            string query = "SELECT * FROM Funcionarios";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Projeto.Modelo.Funcionario funcionario = new Projeto.Modelo.Funcionario
                            {
                                IdFuncionario = (int)reader["idFuncionario"],
                                Nome = (string)reader["nome"],
                                Matricula = (string)reader["matricula"],
                                CPF = (string)reader["cpf"],
                                Endereco = (string)reader["endereco"],
                                Email = (string)reader["email"],
                                Cargo = (string)reader["cargo"],
                                DataAdmissao = (DateTime)reader["data_admissao"],
                                SalarioBruto = (decimal)reader["salario_bruto"],
                                Telefone = (string)reader["telefone"],
                                IdEmpresa = reader["idEmpresa"] != DBNull.Value ? (int)reader["idEmpresa"] : (int?)null,
                                MesReferencia = reader["mesReferencia"] != DBNull.Value ? (int)reader["mesReferencia"] : (int?)null
                            };

                            funcionarios.Add(funcionario);
                        }
                    }
                }
            }

            return funcionarios;
        }

        private List<Projeto.Modelo.Funcionario> ObterFuncionariosPorNome(string nome)
        {
            List<Projeto.Modelo.Funcionario> funcionariosEncontrados = new List<Projeto.Modelo.Funcionario>();
            string connectionString = "Data Source=DESKTOP-30FVRF9\\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True";
            string query = "SELECT * FROM Funcionarios WHERE nome LIKE @Nome";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Nome", "%" + nome + "%");

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Projeto.Modelo.Funcionario funcionario = new Projeto.Modelo.Funcionario
                            {
                                IdFuncionario = (int)reader["idFuncionario"],
                                Nome = (string)reader["nome"],
                                Matricula = (string)reader["matricula"],
                                CPF = (string)reader["cpf"],
                                Endereco = (string)reader["endereco"],
                                Email = (string)reader["email"],
                                Cargo = (string)reader["cargo"],
                                DataAdmissao = (DateTime)reader["data_admissao"],
                                SalarioBruto = (decimal)reader["salario_bruto"],
                                Telefone = (string)reader["telefone"],
                                IdEmpresa = reader["idEmpresa"] != DBNull.Value ? (int)reader["idEmpresa"] : (int?)null,
                                MesReferencia = reader["mesReferencia"] != DBNull.Value ? (int)reader["mesReferencia"] : (int?)null
                            };

                            funcionariosEncontrados.Add(funcionario);
                        }
                    }
                }
            }

            return funcionariosEncontrados;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (dgvFunc.SelectedRows.Count > 0)
            {
                // Coleta os dados dos campos de edição
                string nome = txtNome.Text;
                string matricula = txtMatricula.Text;
                string cpf = txtCPF.Text;
                string endereco = txtEndereco.Text;
                string email = txtEmail.Text;
                string cargo = txtCargo.Text;
                string dataAdmissao = txtAdmissao.Text;
                string salario = txtSalario.Text;
                string telefone = txtTelefone.Text;
                // Coleta os outros campos aqui

                // Atualize a linha selecionada no DataGridView
                DataGridViewRow row = dgvFunc.SelectedRows[0];
                row.Cells["Nome"].Value = nome;
                row.Cells["Matricula"].Value = matricula;
                row.Cells["CPF"].Value = cpf;
                row.Cells["Endereco"].Value = endereco;
                row.Cells["Email"].Value = email;
                row.Cells["Cargo"].Value = cargo;
                row.Cells["DataAdmissao"].Value = dataAdmissao;
                row.Cells["SalarioBruto"].Value = salario;
                row.Cells["Telefone"].Value = telefone;

                // Limpe os campos e desative os botões de alterar e excluir
                LimparCampos();
                btnAlterar.Enabled = false;
                btnExcluir.Enabled = false;
            }
        }

        private int idFuncionarioSelecionado;

        private void dgvFunc_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && e.RowIndex < dgvFunc.Rows.Count)
            {
                // Obtém o ID do funcionário da linha selecionada
                idFuncionarioSelecionado = (int)dgvFunc.Rows[e.RowIndex].Cells["IdFuncionario"].Value;

                // Preenche os campos de inclusão com os valores da linha selecionada
                txtNome.Text = dgvFunc.Rows[e.RowIndex].Cells["Nome"].Value.ToString();
                txtMatricula.Text = dgvFunc.Rows[e.RowIndex].Cells["Matricula"].Value.ToString();
                txtCPF.Text = dgvFunc.Rows[e.RowIndex].Cells["CPF"].Value.ToString();
                txtEndereco.Text = dgvFunc.Rows[e.RowIndex].Cells["Endereco"].Value.ToString();
                txtEmail.Text = dgvFunc.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                txtCargo.Text = dgvFunc.Rows[e.RowIndex].Cells["Cargo"].Value.ToString();
                txtAdmissao.Text = dgvFunc.Rows[e.RowIndex].Cells["DataAdmissao"].Value.ToString();
                txtSalario.Text = dgvFunc.Rows[e.RowIndex].Cells["SalarioBruto"].Value.ToString();
                txtTelefone.Text = dgvFunc.Rows[e.RowIndex].Cells["Telefone"].Value.ToString();
                txtIdEmpresa.Text = dgvFunc.Rows[e.RowIndex].Cells["IdEmpresa"].Value.ToString();
                txtMesReferencia.Text = dgvFunc.Rows[e.RowIndex].Cells["MesReferencia"].Value.ToString();
                // Preencha os outros campos aqui
            }
        }

    }
}
