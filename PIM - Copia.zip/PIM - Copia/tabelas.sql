-- Criar tabela de empresas
CREATE TABLE empresas (
  id INT PRIMARY KEY,
  nome VARCHAR(50) NOT NULL,
  cnpj VARCHAR(14) NOT NULL,
  area_atuacao VARCHAR(50) NOT NULL
);

-- Criar tabela de funcion�rios
CREATE TABLE funcionarios (
  matricula INT IDENTITY(1,1) PRIMARY KEY,
  nome VARCHAR(50) NOT NULL,
  cpf VARCHAR(11) NOT NULL,
  endereco VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  cargo VARCHAR(50) NOT NULL,
  data_admissao DATE NOT NULL,
  data_demissao DATE
);

-- Criar tabela de f�rias
CREATE TABLE ferias (
  salarioFerias DECIMAL(10,2) PRIMARY KEY,
  matricula INT NOT NULL,
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL
);

-- Criar tabela de pagamentos
CREATE TABLE pagamentos (
  id INT IDENTITY(1,1) PRIMARY KEY,
  data_pagamento DATE NOT NULL,
  matricula INT NOT NULL,
  salario_liquido DECIMAL(10,2) NOT NULL,
  salario_bruto DECIMAL(10,2) NOT NULL,
  salarioFerias DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (matricula) REFERENCES funcionarios (matricula),
  FOREIGN KEY (salarioFerias) REFERENCES ferias (salarioFerias)
);

-- Criar tabela de benef�cios
CREATE TABLE descontos (
  id INT IDENTITY(1,1) PRIMARY KEY,
  fgts DECIMAL(10,2) NOT NULL,
  irrf DECIMAL(10,2) NOT NULL,
  inss DECIMAL(10,2) NOT NULL
);

 CREATE TABLE holerite (
  id INT IDENTITY(1,1) PRIMARY KEY,
  descontos INT NOT NULL,
  matricula INT NOT NULL,
  pagamento INT NOT NULL,
  empresa INT NOT NULL, -- Adicionando a refer�ncia � empresa
  FOREIGN KEY (descontos) REFERENCES descontos (id),
  FOREIGN KEY (matricula) REFERENCES funcionarios (matricula),
  FOREIGN KEY (pagamento) REFERENCES pagamentos (id),
  FOREIGN KEY (empresa) REFERENCES empresas (id) -- Refer�ncia � tabela empresas
);


