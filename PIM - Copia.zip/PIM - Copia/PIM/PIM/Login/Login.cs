﻿using PIM.Menu; // Importa o namespace do menu do sistema.
using PIM.Projeto.Controle; // Importa o namespace relacionado ao controle do projeto.
using System;
using System.Windows.Forms;

namespace PIM
{
    public partial class Login : Form
    {
        private Authentication authentication; // Instância da classe Authentication para autenticação do usuário.
        private DatabaseConnection dbConnection; // Instância da classe DatabaseConnection para gerenciar a conexão com o banco de dados.

        public Login()
        {
            InitializeComponent();
            InitializeDatabaseAndAuthentication();
        }

        private void InitializeDatabaseAndAuthentication()
        {
            // Inicializa as instâncias das classes de banco de dados e autenticação
            dbConnection = new DatabaseConnection(@"Data Source=DESKTOP-30FVRF9\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True");
            authentication = new Authentication(dbConnection.GetConnection());
        }

        private void imgSenha_MouseUp(object sender, MouseEventArgs e)
        {
            txtSenha.UseSystemPasswordChar = true; // Ao soltar o botão do mouse na imagem da senha, mostra os caracteres como senhas.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized; // Minimiza a janela quando o botão é clicado.
        }

        private void btnFechar_Click_1(object sender, EventArgs e)
        {
            Application.Exit(); // Fecha a aplicação quando o botão Fechar é clicado.
        }

        private void btnAcessar_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim(); // Obtém o nome de usuário da caixa de texto e remove espaços em branco.
            string senha = txtSenha.Text; // Obtém a senha da caixa de texto.

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(senha))
            {
                MessageBox.Show("Por favor, preencha os campos Login e Senha.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return; // Exibe uma mensagem de aviso se algum campo estiver em branco e sai da função.
            }

            try
            {
                dbConnection.Open(); // Abre a conexão com o banco de dados.

                Usuario usuario = new Usuario
                {
                    Nome = login,
                    Senha = senha
                };

                if (authentication.AuthenticateUser(login, senha))
                {
                    OpenMainMenu(); // Abre o menu principal se a autenticação for bem-sucedida.
                }
                else
                {
                    ShowInvalidCredentialsMessage(); // Exibe uma mensagem de erro se a autenticação falhar.
                }
            }
            catch (Exception erro)
            {
                ShowErrorMessage(erro.Message); // Trata exceções e exibe mensagens de erro em caso de problemas na execução.
            }
            finally
            {
                dbConnection.Close(); // Fecha a conexão com o banco de dados no final, independentemente do resultado.
            }
        }

        private void OpenMainMenu()
        {
            FrmMenu menu = new FrmMenu(); // Cria uma instância do formulário do menu.
            menu.Show(); // Mostra o menu.
            this.Hide(); // Esconde o formulário de login.
        }

        private void ShowInvalidCredentialsMessage()
        {
            MessageBox.Show("Usuário ou senha inválidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error); // Exibe uma mensagem de erro se a autenticação falhar.
            txtLogin.Clear(); // Limpa o campo de nome de usuário.
            txtSenha.Clear(); // Limpa o campo de senha.
            txtLogin.Focus(); // Coloca o foco no campo de nome de usuário.
        }

        private void ShowErrorMessage(string errorMessage)
        {
            MessageBox.Show(errorMessage, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error); // Exibe mensagens de erro em caso de exceções.
        }
    }
}
