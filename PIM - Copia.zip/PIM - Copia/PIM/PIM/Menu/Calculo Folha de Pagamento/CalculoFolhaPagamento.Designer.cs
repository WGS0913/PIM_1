﻿namespace PIM.Menu.Calculo_Folha_de_Pagamento
{
    partial class CalculoFolhaPagamento
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPeriodoFolhaFim = new System.Windows.Forms.Label();
            this.lblCargoFolha = new System.Windows.Forms.Label();
            this.lblSalarioFolha = new System.Windows.Forms.Label();
            this.lblCpfFolha = new System.Windows.Forms.Label();
            this.mtxtCpfFolha = new System.Windows.Forms.MaskedTextBox();
            this.btnCancelarFolha = new System.Windows.Forms.Button();
            this.btnCalcularFolha = new System.Windows.Forms.Button();
            this.lblFuncionarioFolha = new System.Windows.Forms.Label();
            this.cbNomeFunFolha = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.PanelTitleBar = new System.Windows.Forms.Panel();
            this.lblFun = new System.Windows.Forms.Label();
            this.lblPeriodoFolha = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PanelTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPeriodoFolhaFim
            // 
            this.lblPeriodoFolhaFim.AutoSize = true;
            this.lblPeriodoFolhaFim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeriodoFolhaFim.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPeriodoFolhaFim.Location = new System.Drawing.Point(448, 333);
            this.lblPeriodoFolhaFim.Name = "lblPeriodoFolhaFim";
            this.lblPeriodoFolhaFim.Size = new System.Drawing.Size(30, 16);
            this.lblPeriodoFolhaFim.TabIndex = 41;
            this.lblPeriodoFolhaFim.Text = "Até";
            // 
            // lblCargoFolha
            // 
            this.lblCargoFolha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCargoFolha.AutoSize = true;
            this.lblCargoFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargoFolha.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCargoFolha.Location = new System.Drawing.Point(694, 245);
            this.lblCargoFolha.Name = "lblCargoFolha";
            this.lblCargoFolha.Size = new System.Drawing.Size(49, 16);
            this.lblCargoFolha.TabIndex = 39;
            this.lblCargoFolha.Text = "Cargo";
            // 
            // lblSalarioFolha
            // 
            this.lblSalarioFolha.AutoSize = true;
            this.lblSalarioFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFolha.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblSalarioFolha.Location = new System.Drawing.Point(421, 243);
            this.lblSalarioFolha.Name = "lblSalarioFolha";
            this.lblSalarioFolha.Size = new System.Drawing.Size(57, 16);
            this.lblSalarioFolha.TabIndex = 38;
            this.lblSalarioFolha.Text = "Salario";
            // 
            // lblCpfFolha
            // 
            this.lblCpfFolha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCpfFolha.AutoSize = true;
            this.lblCpfFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpfFolha.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCpfFolha.Location = new System.Drawing.Point(510, 171);
            this.lblCpfFolha.Name = "lblCpfFolha";
            this.lblCpfFolha.Size = new System.Drawing.Size(36, 16);
            this.lblCpfFolha.TabIndex = 36;
            this.lblCpfFolha.Text = "CPF";
            // 
            // mtxtCpfFolha
            // 
            this.mtxtCpfFolha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtCpfFolha.Location = new System.Drawing.Point(552, 167);
            this.mtxtCpfFolha.Mask = "000-000-000-00";
            this.mtxtCpfFolha.Name = "mtxtCpfFolha";
            this.mtxtCpfFolha.Size = new System.Drawing.Size(111, 20);
            this.mtxtCpfFolha.TabIndex = 26;
            // 
            // btnCancelarFolha
            // 
            this.btnCancelarFolha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelarFolha.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCancelarFolha.FlatAppearance.BorderSize = 0;
            this.btnCancelarFolha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelarFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarFolha.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCancelarFolha.Location = new System.Drawing.Point(502, 411);
            this.btnCancelarFolha.Name = "btnCancelarFolha";
            this.btnCancelarFolha.Size = new System.Drawing.Size(134, 54);
            this.btnCancelarFolha.TabIndex = 35;
            this.btnCancelarFolha.Text = "Cancelar";
            this.btnCancelarFolha.UseVisualStyleBackColor = false;
            // 
            // btnCalcularFolha
            // 
            this.btnCalcularFolha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCalcularFolha.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCalcularFolha.FlatAppearance.BorderSize = 0;
            this.btnCalcularFolha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcularFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularFolha.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCalcularFolha.Location = new System.Drawing.Point(315, 411);
            this.btnCalcularFolha.Name = "btnCalcularFolha";
            this.btnCalcularFolha.Size = new System.Drawing.Size(134, 54);
            this.btnCalcularFolha.TabIndex = 34;
            this.btnCalcularFolha.Text = "Calcular Salario";
            this.btnCalcularFolha.UseVisualStyleBackColor = false;
            // 
            // lblFuncionarioFolha
            // 
            this.lblFuncionarioFolha.AutoSize = true;
            this.lblFuncionarioFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFuncionarioFolha.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblFuncionarioFolha.Location = new System.Drawing.Point(55, 166);
            this.lblFuncionarioFolha.Name = "lblFuncionarioFolha";
            this.lblFuncionarioFolha.Size = new System.Drawing.Size(155, 16);
            this.lblFuncionarioFolha.TabIndex = 32;
            this.lblFuncionarioFolha.Text = "Nome do Funcionario";
            // 
            // cbNomeFunFolha
            // 
            this.cbNomeFunFolha.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbNomeFunFolha.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbNomeFunFolha.FormattingEnabled = true;
            this.cbNomeFunFolha.Location = new System.Drawing.Point(212, 166);
            this.cbNomeFunFolha.Name = "cbNomeFunFolha";
            this.cbNomeFunFolha.Size = new System.Drawing.Size(237, 21);
            this.cbNomeFunFolha.TabIndex = 24;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(204, 257);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(182, 2);
            this.panel1.TabIndex = 48;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(204, 237);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 19);
            this.textBox1.TabIndex = 47;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(484, 259);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(182, 2);
            this.panel2.TabIndex = 50;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(484, 239);
            this.textBox2.MaxLength = 20;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(181, 19);
            this.textBox2.TabIndex = 49;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(749, 241);
            this.textBox3.MaxLength = 20;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(181, 19);
            this.textBox3.TabIndex = 49;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Location = new System.Drawing.Point(749, 261);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(182, 2);
            this.panel3.TabIndex = 50;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dateTimePicker1.Location = new System.Drawing.Point(155, 329);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(211, 20);
            this.dateTimePicker1.TabIndex = 51;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dateTimePicker2.Location = new System.Drawing.Point(484, 329);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(211, 20);
            this.dateTimePicker2.TabIndex = 52;
            // 
            // PanelTitleBar
            // 
            this.PanelTitleBar.BackColor = System.Drawing.SystemColors.Highlight;
            this.PanelTitleBar.Controls.Add(this.lblFun);
            this.PanelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTitleBar.Location = new System.Drawing.Point(0, 0);
            this.PanelTitleBar.Name = "PanelTitleBar";
            this.PanelTitleBar.Size = new System.Drawing.Size(970, 87);
            this.PanelTitleBar.TabIndex = 86;
            // 
            // lblFun
            // 
            this.lblFun.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblFun.AutoSize = true;
            this.lblFun.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFun.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFun.Location = new System.Drawing.Point(317, 33);
            this.lblFun.Name = "lblFun";
            this.lblFun.Size = new System.Drawing.Size(300, 34);
            this.lblFun.TabIndex = 0;
            this.lblFun.Text = "Folha de Pagamento";
            this.lblFun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPeriodoFolha
            // 
            this.lblPeriodoFolha.AutoSize = true;
            this.lblPeriodoFolha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeriodoFolha.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblPeriodoFolha.Location = new System.Drawing.Point(55, 333);
            this.lblPeriodoFolha.Name = "lblPeriodoFolha";
            this.lblPeriodoFolha.Size = new System.Drawing.Size(94, 16);
            this.lblPeriodoFolha.TabIndex = 40;
            this.lblPeriodoFolha.Text = "Periodo (de)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(55, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 16);
            this.label1.TabIndex = 87;
            this.label1.Text = "Salario (a hora)";
            // 
            // CalculoFolhaPagamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PanelTitleBar);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPeriodoFolhaFim);
            this.Controls.Add(this.lblPeriodoFolha);
            this.Controls.Add(this.lblCargoFolha);
            this.Controls.Add(this.lblSalarioFolha);
            this.Controls.Add(this.lblCpfFolha);
            this.Controls.Add(this.mtxtCpfFolha);
            this.Controls.Add(this.btnCancelarFolha);
            this.Controls.Add(this.btnCalcularFolha);
            this.Controls.Add(this.lblFuncionarioFolha);
            this.Controls.Add(this.cbNomeFunFolha);
            this.Name = "CalculoFolhaPagamento";
            this.Size = new System.Drawing.Size(970, 600);
            this.PanelTitleBar.ResumeLayout(false);
            this.PanelTitleBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPeriodoFolhaFim;
        private System.Windows.Forms.Label lblCargoFolha;
        private System.Windows.Forms.Label lblSalarioFolha;
        private System.Windows.Forms.Label lblCpfFolha;
        private System.Windows.Forms.MaskedTextBox mtxtCpfFolha;
        private System.Windows.Forms.Button btnCancelarFolha;
        private System.Windows.Forms.Button btnCalcularFolha;
        private System.Windows.Forms.Label lblFuncionarioFolha;
        private System.Windows.Forms.ComboBox cbNomeFunFolha;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Panel PanelTitleBar;
        private System.Windows.Forms.Label lblFun;
        private System.Windows.Forms.Label lblPeriodoFolha;
        private System.Windows.Forms.Label label1;
    }
}
