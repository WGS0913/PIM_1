﻿namespace PIM.Menu
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.btnFechar = new System.Windows.Forms.PictureBox();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.PanelTitleBar = new System.Windows.Forms.Panel();
            this.pneLogo = new System.Windows.Forms.Panel();
            this.BtnFolhaPagamento = new System.Windows.Forms.Button();
            this.BtnFolhaFerias = new System.Windows.Forms.Button();
            this.BtnRelatorioFerias = new System.Windows.Forms.Button();
            this.BtnFuncionario = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pneMenu = new System.Windows.Forms.Panel();
            this.panelPrincipal = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.btnFechar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            this.PanelTitleBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pneMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFechar
            // 
            this.btnFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFechar.ErrorImage = global::PIM.Properties.Resources.fechar_1_;
            this.btnFechar.ImageLocation = "center";
            this.btnFechar.Location = new System.Drawing.Point(889, 12);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(25, 25);
            this.btnFechar.TabIndex = 29;
            this.btnFechar.TabStop = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.Image = global::PIM.Properties.Resources.minimize_o_sinal;
            this.btnMinimizar.Location = new System.Drawing.Point(841, 12);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(25, 25);
            this.btnMinimizar.TabIndex = 29;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // PanelTitleBar
            // 
            this.PanelTitleBar.BackColor = System.Drawing.SystemColors.Highlight;
            this.PanelTitleBar.Controls.Add(this.btnMinimizar);
            this.PanelTitleBar.Controls.Add(this.btnFechar);
            this.PanelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTitleBar.Location = new System.Drawing.Point(186, 0);
            this.PanelTitleBar.Name = "PanelTitleBar";
            this.PanelTitleBar.Size = new System.Drawing.Size(941, 62);
            this.PanelTitleBar.TabIndex = 40;
            this.PanelTitleBar.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelTitleBar_Paint);
            this.PanelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PanelTitleBar_MouseDown);
            // 
            // pneLogo
            // 
            this.pneLogo.BackColor = System.Drawing.SystemColors.Highlight;
            this.pneLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pneLogo.Location = new System.Drawing.Point(0, 0);
            this.pneLogo.Name = "pneLogo";
            this.pneLogo.Size = new System.Drawing.Size(186, 62);
            this.pneLogo.TabIndex = 0;
            this.pneLogo.Paint += new System.Windows.Forms.PaintEventHandler(this.pneLogo_Paint);
            // 
            // BtnFolhaPagamento
            // 
            this.BtnFolhaPagamento.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnFolhaPagamento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnFolhaPagamento.FlatAppearance.BorderSize = 0;
            this.BtnFolhaPagamento.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.BtnFolhaPagamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFolhaPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFolhaPagamento.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnFolhaPagamento.Image = ((System.Drawing.Image)(resources.GetObject("BtnFolhaPagamento.Image")));
            this.BtnFolhaPagamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFolhaPagamento.Location = new System.Drawing.Point(-3, 429);
            this.BtnFolhaPagamento.Name = "BtnFolhaPagamento";
            this.BtnFolhaPagamento.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.BtnFolhaPagamento.Size = new System.Drawing.Size(186, 115);
            this.BtnFolhaPagamento.TabIndex = 14;
            this.BtnFolhaPagamento.Text = "  Folha de Pagamento";
            this.BtnFolhaPagamento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFolhaPagamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnFolhaPagamento.UseVisualStyleBackColor = true;
            this.BtnFolhaPagamento.Click += new System.EventHandler(this.BtnFolhaPagamento_Click);
            // 
            // BtnFolhaFerias
            // 
            this.BtnFolhaFerias.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnFolhaFerias.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnFolhaFerias.FlatAppearance.BorderSize = 0;
            this.BtnFolhaFerias.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.BtnFolhaFerias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFolhaFerias.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFolhaFerias.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnFolhaFerias.Image = ((System.Drawing.Image)(resources.GetObject("BtnFolhaFerias.Image")));
            this.BtnFolhaFerias.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFolhaFerias.Location = new System.Drawing.Point(3, 346);
            this.BtnFolhaFerias.Name = "BtnFolhaFerias";
            this.BtnFolhaFerias.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.BtnFolhaFerias.Size = new System.Drawing.Size(186, 109);
            this.BtnFolhaFerias.TabIndex = 15;
            this.BtnFolhaFerias.Text = "  Folha de Ferias";
            this.BtnFolhaFerias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFolhaFerias.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnFolhaFerias.UseVisualStyleBackColor = true;
            this.BtnFolhaFerias.Click += new System.EventHandler(this.BtnFolhaFerias_Click);
            // 
            // BtnRelatorioFerias
            // 
            this.BtnRelatorioFerias.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnRelatorioFerias.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnRelatorioFerias.FlatAppearance.BorderSize = 0;
            this.BtnRelatorioFerias.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.BtnRelatorioFerias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRelatorioFerias.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRelatorioFerias.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnRelatorioFerias.Image = ((System.Drawing.Image)(resources.GetObject("BtnRelatorioFerias.Image")));
            this.BtnRelatorioFerias.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnRelatorioFerias.Location = new System.Drawing.Point(0, 252);
            this.BtnRelatorioFerias.Name = "BtnRelatorioFerias";
            this.BtnRelatorioFerias.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.BtnRelatorioFerias.Size = new System.Drawing.Size(186, 115);
            this.BtnRelatorioFerias.TabIndex = 16;
            this.BtnRelatorioFerias.Text = " Relatorios";
            this.BtnRelatorioFerias.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnRelatorioFerias.UseVisualStyleBackColor = true;
            this.BtnRelatorioFerias.Click += new System.EventHandler(this.BtnRelatorioFerias_Click);
            // 
            // BtnFuncionario
            // 
            this.BtnFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnFuncionario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnFuncionario.FlatAppearance.BorderSize = 0;
            this.BtnFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.BtnFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFuncionario.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnFuncionario.Image = ((System.Drawing.Image)(resources.GetObject("BtnFuncionario.Image")));
            this.BtnFuncionario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFuncionario.Location = new System.Drawing.Point(0, 152);
            this.BtnFuncionario.Name = "BtnFuncionario";
            this.BtnFuncionario.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.BtnFuncionario.Size = new System.Drawing.Size(186, 115);
            this.BtnFuncionario.TabIndex = 17;
            this.BtnFuncionario.Text = "  Funcionario";
            this.BtnFuncionario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFuncionario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnFuncionario.UseVisualStyleBackColor = true;
            this.BtnFuncionario.Click += new System.EventHandler(this.BtnFuncionario_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 62);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(186, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pneMenu
            // 
            this.pneMenu.BackColor = System.Drawing.Color.SteelBlue;
            this.pneMenu.Controls.Add(this.pictureBox1);
            this.pneMenu.Controls.Add(this.BtnFuncionario);
            this.pneMenu.Controls.Add(this.BtnRelatorioFerias);
            this.pneMenu.Controls.Add(this.BtnFolhaFerias);
            this.pneMenu.Controls.Add(this.BtnFolhaPagamento);
            this.pneMenu.Controls.Add(this.pneLogo);
            this.pneMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pneMenu.Location = new System.Drawing.Point(0, 0);
            this.pneMenu.Name = "pneMenu";
            this.pneMenu.Size = new System.Drawing.Size(186, 556);
            this.pneMenu.TabIndex = 25;
            this.pneMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.pneMenu_Paint);
            // 
            // panelPrincipal
            // 
            this.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPrincipal.Location = new System.Drawing.Point(186, 62);
            this.panelPrincipal.Name = "panelPrincipal";
            this.panelPrincipal.Size = new System.Drawing.Size(941, 494);
            this.panelPrincipal.TabIndex = 41;
            this.panelPrincipal.Paint += new System.Windows.Forms.PaintEventHandler(this.panelPrincipal_Paint);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1127, 556);
            this.Controls.Add(this.panelPrincipal);
            this.Controls.Add(this.PanelTitleBar);
            this.Controls.Add(this.pneMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMenu";
            this.Text = "FrmMenu";
            this.Load += new System.EventHandler(this.FrmMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnFechar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            this.PanelTitleBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pneMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private CadastrarFuncionarioCrud frmFuncionario1;
  
        private CadastrarFuncionarioCrud frmUsuario1;
        private frmCalculoFerias frmCalculoFerias1;
        private frmCalculoFerias frmCalculoFerias2;
        private CadastrarFuncionarioCrud cadastrarFuncionarioCrud1;
        private frmCalculoFerias frmCalculoFerias3;
        private Funcionario.Calculos.frmFolhaDePagamento frmFolhaDePagamento1;
        private System.Windows.Forms.PictureBox btnFechar;
        private System.Windows.Forms.PictureBox btnMinimizar;
        private System.Windows.Forms.Panel PanelTitleBar;
        private System.Windows.Forms.Panel pneLogo;
        private System.Windows.Forms.Button BtnFolhaPagamento;
        private System.Windows.Forms.Button BtnFolhaFerias;
        private System.Windows.Forms.Button BtnRelatorioFerias;
        private System.Windows.Forms.Button BtnFuncionario;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pneMenu;
        private System.Windows.Forms.Panel panelPrincipal;
    }
}