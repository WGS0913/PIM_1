﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using PIM.Menu.Funcionario.Calculos;

namespace PIM.Menu
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

      

    
    
        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState= FormWindowState.Minimized;    
        }

  

        private void BtnHome_Click(object sender, EventArgs e)
        {

        }

  

        private void FrmMenu_Load(object sender, EventArgs e)
        {

        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hwnd, int wMsg, int wParam, int IParam);


        private void PanelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void BtnFuncionario_Click(object sender, EventArgs e)
        {
            AbrirFuncionario(new CadastrarFuncionarioCrud());
        }

        private void AbrirFuncionario(UserControl userControl)
        {
            if (this.panelPrincipal.Controls.Count > 0)
                this.panelPrincipal.Controls.RemoveAt(0);

            userControl.Dock = DockStyle.Fill;
            this.panelPrincipal.Controls.Add(userControl);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void PanelTitleBar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pneLogo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pneMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnFolhaPagamento_Click(object sender, EventArgs e)
        {
            AbrirFuncionario(new frmFolhaDePagamento());
        }

        private void panelPrincipal_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BtnRelatorioFerias_Click(object sender, EventArgs e)
        {

        }

        private void BtnFolhaFerias_Click(object sender, EventArgs e)
        {

        }
    }
}
