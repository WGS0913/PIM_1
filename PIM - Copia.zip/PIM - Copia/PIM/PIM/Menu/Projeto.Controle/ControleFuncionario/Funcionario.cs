﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace PIM.Menu
{
    public class FuncionarioController
    {
        private string connectionString = @"Data Source=DESKTOP-30FVRF9\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True"; // Substitua pela sua string de conexão real

        public void HabilitarCampos()
        {
            // Habilitar campos da interface
        }

        public void InicializarElementosDeUI()
        {
            // Inicializar elementos da interface
        }

        public void InserirNoBancoDeDados(string nome, string cpf, string endereco, string email, string cargo, string dataAdmissao, string dataDemissao, string senha)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO funcionarios (nome, cpf, endereco, email, cargo, data_admissao, data_demissao, senha) " +
                    "VALUES (@nome, @cpf, @endereco, @email, @cargo, @data_admissao, @data_demissao, @senha)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@nome", nome);
                    command.Parameters.AddWithValue("@cpf", cpf);
                    command.Parameters.AddWithValue("@endereco", endereco);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@cargo", cargo);
                    command.Parameters.AddWithValue("@data_admissao", DateTime.Parse(dataAdmissao));
                    command.Parameters.AddWithValue("@data_demissao", string.IsNullOrWhiteSpace(dataDemissao) ? DBNull.Value : (object)DateTime.Parse(dataDemissao));
                    command.Parameters.AddWithValue("@senha", senha);

                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Registro inserido com sucesso.");
                            // LimparCampos(); (Chame isso na classe de interface)
                            // InicializarElementosDeUI(); (Chame isso na classe de interface)
                        }
                        else
                        {
                            MessageBox.Show("Erro ao inserir o registro.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro: " + ex.Message);
                    }
                }
            }
        }

        public bool CamposEmBranco(TextBox campo, string nomeDoCampo)
        {
            if (string.IsNullOrWhiteSpace(campo.Text))
            {
                MessageBox.Show($"É obrigatório informar o campo {nomeDoCampo}.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                campo.Focus();
                return true;
            }
            return false;
        }

        // Outros métodos relacionados à lógica de funcionários


    }
}
