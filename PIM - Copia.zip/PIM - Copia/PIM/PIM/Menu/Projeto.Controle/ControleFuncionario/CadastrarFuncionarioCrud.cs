﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections.Generic;

namespace PIM.Menu
{
    public partial class CadastrarFuncionarioCrud : UserControl
    {
        SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-30FVRF9\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True");
        SqlCommand cm = new SqlCommand();

        public CadastrarFuncionarioCrud()
        {
            InitializeComponent();
        }

     


        private void manipularDados()
        {
            btnAlterar.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnNovo.Enabled = false;
            btnGravar.Enabled = false;
            txtCargo.Enabled = true;
            txtEmail.Enabled = true;
            txEndereço.Enabled = true;
            txtMatricula.Enabled = true;
            txtCPF.Enabled = true;
            txtNome.Enabled = true;
            txtAdmissao.Enabled = true;
            txtSalario.Enabled = true;
            txtTelefone.Enabled = true;
            txtIdEmpresa.Enabled = true;
            txtMesReferencia.Enabled = true;
        }

        private void desabilitaCampos()
        {
            txtCargo.Enabled = false;
            txtEmail.Enabled = false;
            txEndereço.Enabled = false;
            txtMatricula.Enabled = false;
            txtCPF.Enabled = false;
            txtNome.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = false;
            btnGravar.Enabled = false;
            txtAdmissao.Enabled = false;
            txtTelefone.Enabled = false;
            txtIdEmpresa.Enabled = false;
            txtMesReferencia.Enabled = false;
            btnNovo.Enabled = true;
            txtNome.Focus();
        }

        private void habilitaCampos()
        {
            txtCargo.Enabled = true;
            txtEmail.Enabled = true;
            txEndereço.Enabled = true;
            txtMatricula.Enabled = true;
            txtCPF.Enabled = true;
            txtNome.Enabled = true;
            txtAdmissao.Enabled = true;
            txtSalario.Enabled = true;
            txtTelefone.Enabled = true;
            txtIdEmpresa.Enabled = true;
            txtMesReferencia.Enabled = true;
            btnGravar.Enabled = true;
            btnCancelar.Enabled = true;
            txtNome.Focus();
            txtBusca.Text = "";
            dgvFunc.DataSource = null;
        }

        private void LimparCampos()
        {
            // Limpe todos os campos de texto na sua interface
            txtCargo.Clear();
            txtEmail.Clear();
            txEndereço.Clear();
            txtMatricula.Clear();
            txtCPF.Clear();
            txtNome.Clear();
            txtAdmissao.Clear();
            txtSalario.Clear();
            txtTelefone.Clear();
            txtIdEmpresa.Clear();
            txtMesReferencia.Clear();
            txtBusca.Clear();    

            // Defina o foco no campo de nome (ou em outro campo, se preferir)
            txtNome.Focus();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaCampos();
            LimparCampos();
        }

        private void CadastrarFuncionarioCrud_Load(object sender, EventArgs e)
        {
            desabilitaCampos();
            LimparCampos();

        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            desabilitaCampos();
            LimparCampos();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (CamposObrigatoriosEstaoPreenchidos())
            {
                try
                {
                    InserirDadosNoBanco();
                }
                catch (Exception erro)
                {
                    MessageBox.Show("Ocorreu um erro: " + erro.Message);
                }
                finally
                {
                    cn.Close();
                }
            }
        }

        private bool CamposObrigatoriosEstaoPreenchidos()
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MostrarMensagemCampoObrigatorio("Nome");
                txtNome.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtCPF.Text))
            {
                MostrarMensagemCampoObrigatorio("CPF");
                txtCPF.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MostrarMensagemCampoObrigatorio("E-mail");
                txtEmail.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtMatricula.Text))
            {
                MostrarMensagemCampoObrigatorio("Matrícula");
                txtMatricula.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtCargo.Text))
            {
                MostrarMensagemCampoObrigatorio("Cargo");
                txtCargo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txEndereço.Text))
            {
                MostrarMensagemCampoObrigatorio("Endereço");
                txEndereço.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtAdmissao.Text))
            {
                MostrarMensagemCampoObrigatorio("Data de Admissão");
                txtAdmissao.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtSalario.Text))
            {
                MostrarMensagemCampoObrigatorio("Salário");
                txtSalario.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtTelefone.Text))
            {
                MostrarMensagemCampoObrigatorio("Telefone");
                txtTelefone.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtIdEmpresa.Text))
            {
                MostrarMensagemCampoObrigatorio("ID da Empresa");
                txtIdEmpresa.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtMesReferencia.Text))
            {
                MostrarMensagemCampoObrigatorio("Mês de Referência");
                txtMesReferencia.Focus();
                return false;
            }

            return true;
        }

        private void MostrarMensagemCampoObrigatorio(string nomeCampo)
        {
            MessageBox.Show("Informe o " + nomeCampo + ".", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void InserirDadosNoBanco()
        {
            try
            {
                cn.Open();

                string strSql = "INSERT INTO funcionarios (nome, cpf, email, matricula, cargo, endereco, data_admissao, salario_bruto, telefone, idEmpresa, mesReferencia) " +
                                "VALUES (@nome, @cpf, @email, @matricula, @cargo, @endereco, @admissao, @salario_bruto, @telefone, @idEmpresa, @mesReferencia)";

                SqlCommand cmd = new SqlCommand(strSql, cn);

                cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                cmd.Parameters.AddWithValue("@cpf", txtCPF.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@matricula", txtMatricula.Text);
                cmd.Parameters.AddWithValue("@cargo", txtCargo.Text);
                cmd.Parameters.AddWithValue("@endereco", txEndereço.Text);
                cmd.Parameters.AddWithValue("@admissao", DateTime.Parse(txtAdmissao.Text));
                cmd.Parameters.AddWithValue("@salario_bruto", decimal.Parse(txtSalario.Text));
                cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text);
                cmd.Parameters.AddWithValue("@idEmpresa", int.Parse(txtIdEmpresa.Text));
                cmd.Parameters.AddWithValue("@mesReferencia", int.Parse(txtMesReferencia.Text));

                cmd.ExecuteNonQuery();


                MessageBox.Show("Funcionário cadastrado com sucesso.");
                desabilitaCampos();
                LimparCampos();
              
            
            }
            catch (Exception erro)
            {
                MessageBox.Show("Ocorreu um erro: " + erro.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        private void txtBusca_TextChanged(object sender, EventArgs e)
        {
            // Obtenha o texto da caixa de busca
            string textoBusca = txtBusca.Text;

            // Verifique se o texto de busca não está vazio
            if (!string.IsNullOrWhiteSpace(textoBusca))
            {
                try
                {
                    cn.Open();

                    // Construa a consulta SQL para buscar funcionários pelo nome
                    string strSql = "SELECT * FROM funcionarios WHERE nome LIKE @nome";

                    SqlCommand cmd = new SqlCommand(strSql, cn);

                    // Adicione o parâmetro com o texto de busca
                    cmd.Parameters.AddWithValue("@nome", "%" + textoBusca + "%");

                    SqlDataAdapter da = new SqlDataAdapter();
                    DataTable dt = new DataTable();

                    da.SelectCommand = cmd;
                    da.Fill(dt);

                    dgvFunc.DataSource = dt;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message);
                }
                finally
                {
                    cn.Close();
                }
            }
            else
            {
                // Se o texto de busca estiver vazio, limpe o DataGridView
                dgvFunc.DataSource = null;
            }
        }

        private void carregaFuncionario()
        {
            if (dgvFunc.SelectedRows.Count > 0)
            {
                // Obtenha o índice da linha selecionada
                int indiceLinhaSelecionada = dgvFunc.SelectedRows[0].Index;

                // Acesse os valores das colunas da linha selecionada
                lblmatriculaSelecionada.Text = dgvFunc["matricula", indiceLinhaSelecionada].Value.ToString();
                txtNome.Text = dgvFunc["nome", indiceLinhaSelecionada].Value.ToString();
                txtCPF.Text = dgvFunc["cpf", indiceLinhaSelecionada].Value.ToString();
                txEndereço.Text = dgvFunc["endereco", indiceLinhaSelecionada].Value.ToString();
                txtEmail.Text = dgvFunc["email", indiceLinhaSelecionada].Value.ToString();
                txtCargo.Text = dgvFunc["cargo", indiceLinhaSelecionada].Value.ToString();
                txtMatricula.Text = lblmatriculaSelecionada.Text;
                txtSalario.Text = dgvFunc["salario_bruto", indiceLinhaSelecionada].Value.ToString();
                txtTelefone.Text = dgvFunc["telefone", indiceLinhaSelecionada].Value.ToString();
                txtIdEmpresa.Text = dgvFunc["idEmpresa", indiceLinhaSelecionada].Value.ToString();
                txtMesReferencia.Text = dgvFunc["mesReferencia", indiceLinhaSelecionada].Value.ToString();
                txtAdmissao.Text = dgvFunc["data_admissao", indiceLinhaSelecionada].Value.ToString();

                manipularDados();

            }
        }

        private void dgvFunc_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            carregaFuncionario();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (CamposObrigatoriosEstaoPreenchidos())
            {
                try
                {
                    cn.Open();

                    // Primeiro, verifique se a empresa com o ID especificado existe
                    string verificaEmpresaSql = "SELECT COUNT(*) FROM Empresa WHERE idEmpresa = @idEmpresa";
                    SqlCommand verificaEmpresaCmd = new SqlCommand(verificaEmpresaSql, cn);
                    verificaEmpresaCmd.Parameters.AddWithValue("@idEmpresa", int.Parse(txtIdEmpresa.Text));

                    int empresaExistente = (int)verificaEmpresaCmd.ExecuteScalar();

                    if (empresaExistente > 0)
                    {
                        // A empresa existe, então proceda com a atualização do funcionário
                        string strSql = "UPDATE funcionarios SET nome = @nome, cpf = @cpf, email = @email, " +
                                        "matricula = @matricula, cargo = @cargo, endereco = @endereco, " +
                                        "data_admissao = @admissao, salario_bruto = @salario, telefone = @telefone, " +
                                        "idEmpresa = @idEmpresa, mesReferencia = @mesReferencia WHERE matricula = @matricula";

                        SqlCommand cmd = new SqlCommand(strSql, cn);

                        cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                        cmd.Parameters.AddWithValue("@cpf", txtCPF.Text);
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@matricula", txtMatricula.Text);
                        cmd.Parameters.AddWithValue("@cargo", txtCargo.Text);
                        cmd.Parameters.AddWithValue("@endereco", txEndereço.Text);
                        cmd.Parameters.AddWithValue("@admissao", DateTime.Parse(txtAdmissao.Text));
                        cmd.Parameters.AddWithValue("@salario", decimal.Parse(txtSalario.Text));
                        cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text);
                        cmd.Parameters.AddWithValue("@idEmpresa", int.Parse(txtIdEmpresa.Text));
                        cmd.Parameters.AddWithValue("@mesReferencia", int.Parse(txtMesReferencia.Text));

                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Funcionário atualizado com sucesso.");
                        desabilitaCampos();
                        LimparCampos();
                        txtBusca.Clear();


                    }
                    else
                    {
                        MessageBox.Show("A empresa com o ID especificado não existe.");
                    }
                }
                catch (Exception erro)
                {
                    MessageBox.Show("Ocorreu um erro: " + erro.Message);
                }
                finally
                {
                    cn.Close();
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dgvFunc.SelectedRows.Count > 0)
            {
                // Obtenha o ID do funcionário da linha selecionada no DataGridView
                int idFuncionario = (int)dgvFunc.SelectedRows[0].Cells["idFuncionario"].Value;

                try
                {
                    cn.Open();

                    // Primeiro, verifique se existem registros na tabela "FolhaPagamento" relacionados a este funcionário
                    string verificaFolhaPagamentoSql = "SELECT COUNT(*) FROM FolhaPagamento WHERE idFuncionario = @idFuncionario";
                    SqlCommand verificaFolhaPagamentoCmd = new SqlCommand(verificaFolhaPagamentoSql, cn);
                    verificaFolhaPagamentoCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);

                    int folhaPagamentoExistente = (int)verificaFolhaPagamentoCmd.ExecuteScalar();

                    if (folhaPagamentoExistente > 0)
                    {
                        // Há registros na tabela "FolhaPagamento" relacionados a este funcionário, exclua-os
                        string deleteFolhaPagamentoSql = "DELETE FROM FolhaPagamento WHERE idFuncionario = @idFuncionario";
                        SqlCommand deleteFolhaPagamentoCmd = new SqlCommand(deleteFolhaPagamentoSql, cn);
                        deleteFolhaPagamentoCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                        deleteFolhaPagamentoCmd.ExecuteNonQuery();
                    }

                    // Agora, verifique se existem registros na tabela "Ferias" relacionados a este funcionário
                    string verificaFeriasSql = "SELECT COUNT(*) FROM Ferias WHERE idFuncionario = @idFuncionario";
                    SqlCommand verificaFeriasCmd = new SqlCommand(verificaFeriasSql, cn);
                    verificaFeriasCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);

                    int feriasExistente = (int)verificaFeriasCmd.ExecuteScalar();

                    if (feriasExistente > 0)
                    {
                        // Há registros na tabela "Ferias" relacionados a este funcionário, exclua-os
                        string deleteFeriasSql = "DELETE FROM Ferias WHERE idFuncionario = @idFuncionario";
                        SqlCommand deleteFeriasCmd = new SqlCommand(deleteFeriasSql, cn);
                        deleteFeriasCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                        deleteFeriasCmd.ExecuteNonQuery();
                    }

                    // Agora, verifique se existem registros na tabela "Ponto" relacionados a este funcionário
                    string verificaPontoSql = "SELECT COUNT(*) FROM Ponto WHERE id_funcionario = @idFuncionario";
                    SqlCommand verificaPontoCmd = new SqlCommand(verificaPontoSql, cn);
                    verificaPontoCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);

                    int pontoExistente = (int)verificaPontoCmd.ExecuteScalar();

                    if (pontoExistente > 0)
                    {
                        // Há registros na tabela "Ponto" relacionados a este funcionário, exclua-os
                        string deletePontoSql = "DELETE FROM Ponto WHERE id_funcionario = @idFuncionario";
                        SqlCommand deletePontoCmd = new SqlCommand(deletePontoSql, cn);
                        deletePontoCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                        deletePontoCmd.ExecuteNonQuery();
                    }

                    // Agora, exclua o funcionário da tabela "Funcionarios"
                    string deleteFuncionarioSql = "DELETE FROM Funcionarios WHERE idFuncionario = @idFuncionario";
                    SqlCommand deleteFuncionarioCmd = new SqlCommand(deleteFuncionarioSql, cn);
                    deleteFuncionarioCmd.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                    deleteFuncionarioCmd.ExecuteNonQuery();

                    MessageBox.Show("Funcionário excluído com sucesso.");
                    desabilitaCampos();
                    LimparCampos();
                   


                }
                catch (Exception erro)
                {
                    MessageBox.Show("Ocorreu um erro ao excluir o funcionário: " + erro.Message);
                }
                finally
                {
                    cn.Close();
                }
            }
            else
            {
                MessageBox.Show("Selecione um funcionário na lista para excluí-lo.");
            }
        }
    }
}