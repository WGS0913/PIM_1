﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;

namespace PIM.Projeto.Controle
{
    public class Usuario
    {
        public int IdUsuario { get; set; } // Propriedade para o ID do usuário
        public string Nome { get; set; }   // Propriedade para o nome do usuário
        public string Matricula { get; set; } // Propriedade para a matrícula do usuário
        public string Senha { get; set; }  // Propriedade para a senha do usuário
    }


    public class DatabaseConnection
    {
        private SqlConnection connection; // Objeto de conexão com o banco de dados

        public DatabaseConnection(string connectionString)
        {
            connection = new SqlConnection(connectionString); // Inicializa a conexão com a string de conexão fornecida
        }

        public void Open()
        {
            if (connection.State != ConnectionState.Open)
            {
                connection.Open(); // Abre a conexão com o banco de dados se não estiver aberta
            }
        }

        public void Close()
        {
            if (connection.State != ConnectionState.Closed)
            {
                connection.Close(); // Fecha a conexão com o banco de dados se estiver aberta
            }
        }

        public SqlConnection GetConnection()
        {
            return connection; // Retorna o objeto de conexão, que pode ser usado para realizar consultas SQL
        }
    }

    public class Authentication
    {
        private SqlConnection connection; // Objeto de conexão com o banco de dados

        public Authentication(SqlConnection connection)
        {
            this.connection = connection; // Inicializa a conexão com o banco de dados no construtor
        }

        public bool AuthenticateUser(string login, string senha)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM Usuario WHERE (nome = @Login OR matricula = @Login) AND senha = @Senha", connection);
            command.Parameters.AddWithValue("@Login", login); // Parâmetro para o nome de usuário ou matricula 
            command.Parameters.AddWithValue("@Senha", senha); // Parâmetro para a senha

            SqlDataReader reader = command.ExecuteReader(); // Executa a consulta SQL
            bool isAuthenticated = reader.HasRows; // Verifica se a consulta retornou algum resultado
            reader.Close(); // Fecha o leitor
            return isAuthenticated; // Retorna verdadeiro se o usuário for autenticado, falso caso contrário
        }
    }


    public class Funcionario
    {
        public int Id { get; set; }
        public decimal Salario { get; set; }
        public string Cargo { get; set; }
        public string Email { get; set; }
        public string Endereco { get; set; }
        public string Senha { get; set; }
        public string CPF { get; set; }
        public string Nome { get; set; }
        public string Matricula { get; set; }

        public bool SalvarNoBanco()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("SuaStringDeConexao"))
                {
                    connection.Open();

                    string query = "INSERT INTO Funcionarios (Salario, Cargo, Email, Endereco, Senha, CPF, Nome, Matricula) " +
                        "VALUES (@Salario, @Cargo, @Email, @Endereco, @Senha, @CPF, @Nome, @Matricula)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Salario", Salario);
                        command.Parameters.AddWithValue("@Cargo", Cargo);
                        command.Parameters.AddWithValue("@Email", Email);
                        command.Parameters.AddWithValue("@Endereco", Endereco);
                        command.Parameters.AddWithValue("@Senha", Senha);
                        command.Parameters.AddWithValue("@CPF", CPF);
                        command.Parameters.AddWithValue("@Nome", Nome);
                        command.Parameters.AddWithValue("@Matricula", Matricula);

                        command.ExecuteNonQuery();
                    }
                }

                // Se a inserção no banco de dados ocorreu sem problemas, retornamos true
                return true;
            }
            catch (Exception ex)
            {
                // Em caso de erro, você pode lidar com exceções aqui, se necessário.
                // E retornar false para indicar que não foi possível salvar no banco de dados.
                return false;
            }
        }
    }
}
