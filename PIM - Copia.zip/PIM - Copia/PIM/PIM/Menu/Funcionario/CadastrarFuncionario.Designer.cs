﻿namespace PIM.Menu
{
    partial class CadastrarFuncionario
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel10 = new System.Windows.Forms.Panel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAddFuncionario = new System.Windows.Forms.Button();
            this.Senha = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.lblHoraSaida = new System.Windows.Forms.Label();
            this.mskHoraEntrada = new System.Windows.Forms.MaskedTextBox();
            this.lblHoraEntrada = new System.Windows.Forms.Label();
            this.lblDataAdimissao = new System.Windows.Forms.Label();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.lblEMail = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblCpf = new System.Windows.Forms.Label();
            this.lblNameFuncionario = new System.Windows.Forms.Label();
            this.lblFun = new System.Windows.Forms.Label();
            this.PanelTitleBar = new System.Windows.Forms.Panel();
            this.PanelTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel10.Location = new System.Drawing.Point(219, 274);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(223, 2);
            this.panel10.TabIndex = 77;
            // 
            // textBox8
            // 
            this.textBox8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(219, 254);
            this.textBox8.MaxLength = 20;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(222, 19);
            this.textBox8.TabIndex = 74;
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel8.Location = new System.Drawing.Point(446, 333);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(49, 2);
            this.panel8.TabIndex = 76;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.maskedTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maskedTextBox1.Location = new System.Drawing.Point(446, 318);
            this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox1.Mask = "00:00";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(49, 13);
            this.maskedTextBox1.TabIndex = 73;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel9.Location = new System.Drawing.Point(627, 218);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(105, 2);
            this.panel9.TabIndex = 83;
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel7.Location = new System.Drawing.Point(603, 338);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(105, 2);
            this.panel7.TabIndex = 82;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(627, 198);
            this.textBox3.MaxLength = 20;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(104, 19);
            this.textBox3.TabIndex = 80;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel6.Location = new System.Drawing.Point(781, 342);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(105, 2);
            this.panel6.TabIndex = 81;
            // 
            // textBox7
            // 
            this.textBox7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(603, 318);
            this.textBox7.MaxLength = 20;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(104, 19);
            this.textBox7.TabIndex = 79;
            // 
            // textBox6
            // 
            this.textBox6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(781, 322);
            this.textBox6.MaxLength = 20;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(104, 19);
            this.textBox6.TabIndex = 78;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel5.Location = new System.Drawing.Point(259, 217);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(65, 2);
            this.panel5.TabIndex = 75;
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(259, 197);
            this.textBox5.MaxLength = 20;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(64, 19);
            this.textBox5.TabIndex = 72;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Location = new System.Drawing.Point(233, 332);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(58, 2);
            this.panel3.TabIndex = 71;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Location = new System.Drawing.Point(416, 217);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(125, 2);
            this.panel4.TabIndex = 70;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(558, 177);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 2);
            this.panel2.TabIndex = 69;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(257, 182);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(194, 2);
            this.panel1.TabIndex = 68;
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(416, 197);
            this.textBox4.MaxLength = 20;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(124, 19);
            this.textBox4.TabIndex = 65;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(558, 157);
            this.textBox2.MaxLength = 20;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(193, 19);
            this.textBox2.TabIndex = 67;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(257, 162);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(193, 19);
            this.textBox1.TabIndex = 66;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dateTimePicker1.Location = new System.Drawing.Point(633, 257);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(211, 20);
            this.dateTimePicker1.TabIndex = 64;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Location = new System.Drawing.Point(275, 393);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(186, 58);
            this.button1.TabIndex = 63;
            this.button1.Text = "Adicionar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnAddFuncionario
            // 
            this.btnAddFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAddFuncionario.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFuncionario.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnAddFuncionario.Location = new System.Drawing.Point(545, 393);
            this.btnAddFuncionario.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddFuncionario.Name = "btnAddFuncionario";
            this.btnAddFuncionario.Size = new System.Drawing.Size(186, 58);
            this.btnAddFuncionario.TabIndex = 62;
            this.btnAddFuncionario.Text = "Filtrar Busca";
            this.btnAddFuncionario.UseVisualStyleBackColor = false;
            // 
            // Senha
            // 
            this.Senha.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Senha.AutoSize = true;
            this.Senha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Senha.Location = new System.Drawing.Point(730, 325);
            this.Senha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Senha.Name = "Senha";
            this.Senha.Size = new System.Drawing.Size(43, 15);
            this.Senha.TabIndex = 59;
            this.Senha.Text = "Senha";
            // 
            // lblUsuario
            // 
            this.lblUsuario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.Location = new System.Drawing.Point(544, 321);
            this.lblUsuario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(50, 15);
            this.lblUsuario.TabIndex = 61;
            this.lblUsuario.Text = "Usuario";
            // 
            // lblHoraSaida
            // 
            this.lblHoraSaida.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHoraSaida.AutoSize = true;
            this.lblHoraSaida.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraSaida.Location = new System.Drawing.Point(356, 318);
            this.lblHoraSaida.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHoraSaida.Name = "lblHoraSaida";
            this.lblHoraSaida.Size = new System.Drawing.Size(86, 15);
            this.lblHoraSaida.TabIndex = 60;
            this.lblHoraSaida.Text = "Hora de Saida";
            // 
            // mskHoraEntrada
            // 
            this.mskHoraEntrada.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.mskHoraEntrada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mskHoraEntrada.Location = new System.Drawing.Point(233, 317);
            this.mskHoraEntrada.Margin = new System.Windows.Forms.Padding(2);
            this.mskHoraEntrada.Mask = "00:00";
            this.mskHoraEntrada.Name = "mskHoraEntrada";
            this.mskHoraEntrada.Size = new System.Drawing.Size(58, 13);
            this.mskHoraEntrada.TabIndex = 56;
            this.mskHoraEntrada.ValidatingType = typeof(System.DateTime);
            // 
            // lblHoraEntrada
            // 
            this.lblHoraEntrada.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblHoraEntrada.AutoSize = true;
            this.lblHoraEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraEntrada.Location = new System.Drawing.Point(132, 315);
            this.lblHoraEntrada.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHoraEntrada.Name = "lblHoraEntrada";
            this.lblHoraEntrada.Size = new System.Drawing.Size(97, 15);
            this.lblHoraEntrada.TabIndex = 58;
            this.lblHoraEntrada.Text = "Hora de Entrada";
            // 
            // lblDataAdimissao
            // 
            this.lblDataAdimissao.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblDataAdimissao.AutoSize = true;
            this.lblDataAdimissao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataAdimissao.Location = new System.Drawing.Point(517, 261);
            this.lblDataAdimissao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDataAdimissao.Name = "lblDataAdimissao";
            this.lblDataAdimissao.Size = new System.Drawing.Size(100, 15);
            this.lblDataAdimissao.TabIndex = 57;
            this.lblDataAdimissao.Text = "Dia de Admissão";
            this.lblDataAdimissao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartamento.Location = new System.Drawing.Point(132, 258);
            this.lblDepartamento.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(86, 15);
            this.lblDepartamento.TabIndex = 55;
            this.lblDepartamento.Text = "Departamento";
            // 
            // lblEMail
            // 
            this.lblEMail.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblEMail.AutoSize = true;
            this.lblEMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEMail.Location = new System.Drawing.Point(574, 201);
            this.lblEMail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEMail.Name = "lblEMail";
            this.lblEMail.Size = new System.Drawing.Size(43, 15);
            this.lblEMail.TabIndex = 54;
            this.lblEMail.Text = "E-mail";
            // 
            // lblSalario
            // 
            this.lblSalario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblSalario.AutoSize = true;
            this.lblSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalario.Location = new System.Drawing.Point(339, 201);
            this.lblSalario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(72, 15);
            this.lblSalario.TabIndex = 53;
            this.lblSalario.Text = "Salario total";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioHora.Location = new System.Drawing.Point(132, 204);
            this.lblSalarioHora.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(122, 15);
            this.lblSalarioHora.TabIndex = 52;
            this.lblSalarioHora.Text = "salario por (por hora)";
            // 
            // lblCpf
            // 
            this.lblCpf.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblCpf.AutoSize = true;
            this.lblCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpf.Location = new System.Drawing.Point(526, 161);
            this.lblCpf.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCpf.Name = "lblCpf";
            this.lblCpf.Size = new System.Drawing.Size(30, 15);
            this.lblCpf.TabIndex = 51;
            this.lblCpf.Text = "CPF";
            // 
            // lblNameFuncionario
            // 
            this.lblNameFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblNameFuncionario.AutoSize = true;
            this.lblNameFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameFuncionario.Location = new System.Drawing.Point(132, 164);
            this.lblNameFuncionario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNameFuncionario.Name = "lblNameFuncionario";
            this.lblNameFuncionario.Size = new System.Drawing.Size(120, 15);
            this.lblNameFuncionario.TabIndex = 50;
            this.lblNameFuncionario.Text = "nome do funcionario";
            // 
            // lblFun
            // 
            this.lblFun.AutoSize = true;
            this.lblFun.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFun.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFun.Location = new System.Drawing.Point(315, 33);
            this.lblFun.Name = "lblFun";
            this.lblFun.Size = new System.Drawing.Size(325, 34);
            this.lblFun.TabIndex = 0;
            this.lblFun.Text = "Cadastrar Funcionario";
            this.lblFun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PanelTitleBar
            // 
            this.PanelTitleBar.BackColor = System.Drawing.SystemColors.Highlight;
            this.PanelTitleBar.Controls.Add(this.lblFun);
            this.PanelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTitleBar.Location = new System.Drawing.Point(0, 0);
            this.PanelTitleBar.Name = "PanelTitleBar";
            this.PanelTitleBar.Size = new System.Drawing.Size(949, 87);
            this.PanelTitleBar.TabIndex = 84;
            // 
            // CadastrarFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.PanelTitleBar);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAddFuncionario);
            this.Controls.Add(this.Senha);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.lblHoraSaida);
            this.Controls.Add(this.mskHoraEntrada);
            this.Controls.Add(this.lblHoraEntrada);
            this.Controls.Add(this.lblDataAdimissao);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.lblEMail);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblCpf);
            this.Controls.Add(this.lblNameFuncionario);
            this.Name = "CadastrarFuncionario";
            this.Size = new System.Drawing.Size(949, 600);
            this.PanelTitleBar.ResumeLayout(false);
            this.PanelTitleBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnAddFuncionario;
        private System.Windows.Forms.Label Senha;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label lblHoraSaida;
        private System.Windows.Forms.MaskedTextBox mskHoraEntrada;
        private System.Windows.Forms.Label lblHoraEntrada;
        private System.Windows.Forms.Label lblDataAdimissao;
        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.Label lblEMail;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblCpf;
        private System.Windows.Forms.Label lblNameFuncionario;
        private System.Windows.Forms.Label lblFun;
        private System.Windows.Forms.Panel PanelTitleBar;
    }
}
