﻿namespace PIM.Menu.Funcionario.Calculos
{
    partial class frmFolhaDePagamento
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFolhaDePagamento));
            this.SalvarButton = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.idFuncionarioTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CalcularSalario = new System.Windows.Forms.Button();
            this.resultadoLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SalvarButton
            // 
            this.SalvarButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SalvarButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SalvarButton.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalvarButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SalvarButton.Image = ((System.Drawing.Image)(resources.GetObject("SalvarButton.Image")));
            this.SalvarButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SalvarButton.Location = new System.Drawing.Point(140, 221);
            this.SalvarButton.Name = "SalvarButton";
            this.SalvarButton.Size = new System.Drawing.Size(128, 46);
            this.SalvarButton.TabIndex = 55;
            this.SalvarButton.Text = "Gravar";
            this.SalvarButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SalvarButton.UseVisualStyleBackColor = true;
            this.SalvarButton.Click += new System.EventHandler(this.SalvarButton_Click);
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel10.Location = new System.Drawing.Point(429, 172);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(173, 2);
            this.panel10.TabIndex = 94;
            // 
            // idFuncionarioTextBox
            // 
            this.idFuncionarioTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.idFuncionarioTextBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.idFuncionarioTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.idFuncionarioTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idFuncionarioTextBox.Location = new System.Drawing.Point(429, 152);
            this.idFuncionarioTextBox.MaxLength = 20;
            this.idFuncionarioTextBox.Name = "idFuncionarioTextBox";
            this.idFuncionarioTextBox.Size = new System.Drawing.Size(172, 19);
            this.idFuncionarioTextBox.TabIndex = 93;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(136, 154);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(287, 20);
            this.label9.TabIndex = 92;
            this.label9.Text = "Infome a Matricula do Funcionario ";
            // 
            // CalcularSalario
            // 
            this.CalcularSalario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CalcularSalario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CalcularSalario.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalcularSalario.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.CalcularSalario.Location = new System.Drawing.Point(326, 221);
            this.CalcularSalario.Name = "CalcularSalario";
            this.CalcularSalario.Size = new System.Drawing.Size(128, 46);
            this.CalcularSalario.TabIndex = 95;
            this.CalcularSalario.Text = "Calcular";
            this.CalcularSalario.UseVisualStyleBackColor = true;
            this.CalcularSalario.Click += new System.EventHandler(this.CalcularSalario_Click);
            // 
            // resultadoLabel
            // 
            this.resultadoLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.resultadoLabel.AutoSize = true;
            this.resultadoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultadoLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.resultadoLabel.Location = new System.Drawing.Point(635, 103);
            this.resultadoLabel.Name = "resultadoLabel";
            this.resultadoLabel.Size = new System.Drawing.Size(0, 18);
            this.resultadoLabel.TabIndex = 92;
            // 
            // frmFolhaDePagamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.CalcularSalario);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.idFuncionarioTextBox);
            this.Controls.Add(this.resultadoLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.SalvarButton);
            this.Name = "frmFolhaDePagamento";
            this.Size = new System.Drawing.Size(970, 600);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SalvarButton;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox idFuncionarioTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button CalcularSalario;
        private System.Windows.Forms.Label resultadoLabel;
    }
}
