﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM.Menu.Funcionario.Calculos
{
    internal class Calculos_Folha_Pagamento
    {
         

    public class CalculadoraSalario
    {
        public decimal CalcularSalarioLiquido(decimal salarioBruto)
        {
            decimal descontoIR = CalcularDescontoImpostoRenda(salarioBruto);
            decimal descontoPrevidencia = CalcularDescontoPrevidenciaSocial(salarioBruto);

            decimal salarioLiquido = salarioBruto - descontoIR - descontoPrevidencia;

            return salarioLiquido;
        }

        public decimal CalcularDescontoImpostoRenda(decimal salarioBruto)
        {
            decimal descontoIR = 0;

            // Aplicar alíquotas de imposto de renda de acordo com as faixas de renda
            if (salarioBruto <= 1903.98m)
            {
                descontoIR = 0;
            }
            else if (salarioBruto <= 2826.65m)
            {
                descontoIR = (salarioBruto - 1903.98m) * 0.075m;
            }
            else if (salarioBruto <= 3751.05m)
            {
                descontoIR = (salarioBruto - 2826.65m) * 0.15m + 69.66m;
            }
            else if (salarioBruto <= 4664.68m)
            {
                descontoIR = (salarioBruto - 3751.05m) * 0.225m + 138.66m;
            }
            else
            {
                descontoIR = (salarioBruto - 4664.68m) * 0.275m + 205.66m;
            }

            return descontoIR;
        }

        public decimal CalcularDescontoPrevidenciaSocial(decimal salarioBruto)
        {
            // Aplicar uma taxa fixa ou porcentagem para a Previdência Social
            decimal taxaPrevidencia = 0.11m; // 11% (exemplo)
            decimal descontoPrevidencia = salarioBruto * taxaPrevidencia;

            return descontoPrevidencia;
        }
    }

        class Program
        {
            static void Main()
            {
                decimal salarioBruto = 5000.00m; // Substitua pelo valor bruto informado

                CalculadoraSalario calculadora = new CalculadoraSalario();
                decimal salarioLiquido = calculadora.CalcularSalarioLiquido(salarioBruto);

                Console.WriteLine("Salário Bruto: " + salarioBruto.ToString("C"));
                Console.WriteLine("Salário Líquido: " + salarioLiquido.ToString("C"));

                Console.ReadKey();
            }
        }

    }
}
