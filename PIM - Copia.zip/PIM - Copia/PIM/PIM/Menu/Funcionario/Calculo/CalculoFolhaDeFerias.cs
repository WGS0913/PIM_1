﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM.Menu.Funcionario.Calculos
{
    public class CalculoFerias
    {
        public decimal CalcularSalarioFerias(decimal salarioMensal, DateTime dataInicio, DateTime dataFim)
        {
            // Calcula o número de dias de férias
            int numeroDiasFerias = (int)(dataFim - dataInicio).TotalDays + 1;

            // Calcula o valor do salário de férias
            decimal valorSalarioFerias = (salarioMensal / 30) * numeroDiasFerias;

            return valorSalarioFerias;
        }
    }
}
