﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PIM.Menu.Funcionario.Calculos
{
    public partial class frmFolhaDePagamento : UserControl
    {
     
        private string connectionString = "Data Source=DESKTOP-30FVRF9\\SQLGOMES;Initial Catalog=db_PIM;Integrated Security=True"; 
        private decimal salarioBruto;

        public frmFolhaDePagamento()
        {
            InitializeComponent();
        }

        private void CalcularSalario_Click(object sender, EventArgs e)
        {  
            if (int.TryParse(idFuncionarioTextBox.Text, out int idFuncionario))
            {
                if (FuncionarioExiste(idFuncionario))
                {
                    salarioBruto = ObterSalarioBruto(idFuncionario);
                    decimal fgts = CalcularFGTS(salarioBruto);
                    decimal irrf = CalcularIRRF(salarioBruto);
                    decimal inss = CalcularINSS(salarioBruto);
                    decimal salarioLiquido = salarioBruto - fgts - irrf - inss;

                    resultadoLabel.Text = $"Salário Bruto: R$ {salarioBruto:F2}\nFGTS: R$ {fgts:F2}\nIRRF: R$ {irrf:F2}\nINSS: R$ {inss:F2}\nSalário Líquido: R$ {salarioLiquido:F2}";
                }
                else
                {
                    resultadoLabel.Text = "ID do funcionário não encontrado .";
                }
            }
            else
            {
                resultadoLabel.Text = "insira um ID válido.";
            }
        }

        private bool FuncionarioExiste(int idFuncionario)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Funcionarios WHERE idFuncionario = @idFuncionario";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }


        private decimal ObterSalarioBruto(int idFuncionario)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT salario_bruto FROM Funcionarios WHERE idFuncionario = @idFuncionario";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                    return Convert.ToDecimal(command.ExecuteScalar());
                }
            }
        }

        private decimal CalcularFGTS(decimal salarioBruto)
        {
            return salarioBruto * 0.08m; // Exemplo de cálculo do FGTS (8% do salário bruto)
        }

        private decimal CalcularIRRF(decimal salarioBruto)
        {
            return salarioBruto * 0.1m; // Exemplo de cálculo do IRRF (10% do salário bruto)
        }

        private decimal CalcularINSS(decimal salarioBruto)
        {
            return salarioBruto * 0.12m; // Exemplo de cálculo do INSS (12% do salário bruto)
        }


        private void InserirFolhaPagamento(int idFuncionario, decimal salarioLiquido, decimal fgts, decimal irrf, decimal inss)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO FolhaPagamento (idFuncionario, data_pagamento, salario_liquido, salarioFerias, fgts, irrf, inss) VALUES (@idFuncionario, @dataPagamento, @salarioLiquido, 0, @fgts, @irrf, @inss)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idFuncionario", idFuncionario);
                    command.Parameters.AddWithValue("@dataPagamento", DateTime.Now);
                    command.Parameters.AddWithValue("@salarioLiquido", salarioLiquido);
                    command.Parameters.AddWithValue("@fgts", fgts);
                    command.Parameters.AddWithValue("@irrf", irrf);
                    command.Parameters.AddWithValue("@inss", inss);
                    command.ExecuteNonQuery();
                }
            }
        }

        private void SalvarButton_Click(object sender, EventArgs e)
        {
            if (salarioBruto > 0)
            {
                int idFuncionario = Convert.ToInt32(idFuncionarioTextBox.Text);
                decimal fgts = CalcularFGTS(salarioBruto);
                decimal irrf = CalcularIRRF(salarioBruto);
                decimal inss = CalcularINSS(salarioBruto);
                decimal salarioLiquido = salarioBruto - fgts - irrf - inss;

                resultadoLabel.Text = $"Salário Bruto: R$ {salarioBruto:F2}\nFGTS: R$ {fgts:F2}\nIRRF: R$ {irrf:F2}\nINSS: R$ {inss:F2}\nSalário Líquido: R$ {salarioLiquido:F2}";

                try
                {
                    InserirFolhaPagamento(idFuncionario, salarioLiquido, fgts, irrf, inss);
                    MessageBox.Show("Salário Bruto salvo na Folha de Pagamento com sucesso!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao salvar o salário bruto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Primeiro calcule o salário antes de salvar.");
            }
        }





    }
}
