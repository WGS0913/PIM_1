﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PIM.Menu.Funcionario.Calculos;

namespace PIM.Menu.Funcionario.Calculos
{
    public partial class FolhaDeFerias : Form
    {
        public FolhaDeFerias()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            // Obtenha os valores dos campos de texto
            decimal salarioMensal = decimal.Parse(txtSalario.Text);
            DateTime dataInicio = DateTime.Parse(txtDataInicio.Text);
            DateTime dataTermino = DateTime.Parse(txtDataTermino.Text);

            // Chame o método CalcularSalarioFerias e obtenha o resultado
            CalculoFerias calculadora = new CalculoFerias();
            decimal valorSalarioFerias = calculadora.CalcularSalarioFerias(salarioMensal, dataInicio, dataTermino);

            // Calcule o número de dias de férias
            int numeroDiasFerias = (dataTermino - dataInicio).Days + 1;

            // Formate o resultado
            string resultadoFormatado = string.Format("Valor do salário de férias para {0} dias de férias: R$ {1:F2}", numeroDiasFerias, valorSalarioFerias);

            // Atualize qualquer campo na interface do usuário, se necessário
            // Por exemplo, você pode exibir o resultado em um rótulo (label)
            lblResultado.Text = resultadoFormatado;

        }
    }
}
