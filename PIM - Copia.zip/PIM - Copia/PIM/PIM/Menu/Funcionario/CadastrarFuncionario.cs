﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM.Menu
{
    public partial class CadastrarFuncionario : UserControl
    {
        public CadastrarFuncionario()
        {
            InitializeComponent();
        }

        private void lblSalarioHora_Click(object sender, EventArgs e)
        {

        }

        private void mskHoraEntrada_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
