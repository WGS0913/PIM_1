﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace PIM.Menu
{
    public partial class FrmListarFunciona : UserControl
    {
        public FrmListarFunciona()
        {
            InitializeComponent();
        }

        //Inicio da conexão com o banco de dados sql Server para a tabela Login
        SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-30FVRF9\SQLGOMES;Integrated Security=SSPI;Initial Catalog=db_pim");


       SqlCommand cm = new SqlCommand();

        SqlDataReader dt;

        //FIM da conexão com o banco de dados SQL Server 

        private void desabilitaCampos()
        {
            txtNome.Enabled = false;
            txtSenha.Enabled = false;
            txtMatricula.Enabled = false;
            btnGravar.Enabled = false;
            brnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCanecelar.Enabled = false;


        }
        private void HabilitaCampos()
        {
            txtNome.Enabled = true;
            txtSenha.Enabled = true;
            txtMatricula.Enabled = true;
            btnGravar.Enabled = true;
            brnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCanecelar.Enabled = true;
            btnNovo.Enabled = false;
            txtNome.Focus();
        }

        private void LimparCampos()
        {
            txtNome.Text = "";
            txtSenha.Text = "";
            txtBusca.Text = "";
            txtMatricula.Text = "";
            txtNome.Focus();
        }

        private void FrmFuncionario_Load(object sender, EventArgs e)
        {
            desabilitaCampos();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            HabilitaCampos();
        }

        private void btnCanecelar_Click(object sender, EventArgs e)
        {
            desabilitaCampos();
            LimparCampos();
            btnNovo.Enabled = true;
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Obrgatório informar o campo Nome. ","Atenção",MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Focus();
            } 
            else if(txtMatricula.Text == "")
            {
                MessageBox.Show("Obrgatório informar o campo Matricula. ", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMatricula.Focus();
            }
            else if (txtSenha.Text == "")
            {
                MessageBox.Show("Obrgatório informar o campo Senha . ", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSenha.Focus();
            }
            else if (txtSenha.Text.Length < 8)
            {
                MessageBox.Show("O campo Senha deve conter no mínimo 8 dígitos. ", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSenha.Focus();
            }
            else
            {

                try 
                {
                    string nome = txtNome.Text;
                    string Matricula = txtMatricula.Text;
                    string Senha = txtSenha.Text;

                    string strSql = "INSERT INTO Usuario (nome, Matricula, senha) VALUES (@nome, @Matricula, @senha)";

                    
                    cm.CommandText = strSql;
                    cm.Connection = cn;

                    cm.Parameters.Add(new SqlParameter("@nome", SqlDbType.VarChar)).Value = nome;
                    cm.Parameters.Add(new SqlParameter("@Matricula", SqlDbType.VarChar)).Value = Matricula;
                    cm.Parameters.Add(new SqlParameter("@senha", SqlDbType.VarChar)).Value = Senha;

                    cn.Open();
                    cm.ExecuteNonQuery();

                    cn.Close(); 

                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message);
                    cn.Close();
                }
                finally
                {
                    LimparCampos();
                    cn.Close();
                    MessageBox.Show("Dados foram salvos com sucesso. ", "Atenção", MessageBoxButtons.OK);
                    txtMatricula.Focus();
                }
              

            }
        }
    }
}
