﻿namespace PIM.Menu.Funcionario
{
    partial class ListarFuncionario
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtnFiltroCpfFuncionario = new System.Windows.Forms.RadioButton();
            this.rbtnNomeFuncionario = new System.Windows.Forms.RadioButton();
            this.lblFiltroFuncionario = new System.Windows.Forms.Label();
            this.BtnPesquisarFuncionario = new System.Windows.Forms.Button();
            this.lblPesFuncionario = new System.Windows.Forms.Label();
            this.btnExcluFuncionario = new System.Windows.Forms.Button();
            this.BtnEditFuncionario = new System.Windows.Forms.Button();
            this.DgvFuncionario = new System.Windows.Forms.DataGridView();
            this.PanelTitleBar = new System.Windows.Forms.Panel();
            this.lblFun = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.DgvFuncionario)).BeginInit();
            this.PanelTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbtnFiltroCpfFuncionario
            // 
            this.rbtnFiltroCpfFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rbtnFiltroCpfFuncionario.AutoSize = true;
            this.rbtnFiltroCpfFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFiltroCpfFuncionario.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rbtnFiltroCpfFuncionario.Location = new System.Drawing.Point(422, 414);
            this.rbtnFiltroCpfFuncionario.Name = "rbtnFiltroCpfFuncionario";
            this.rbtnFiltroCpfFuncionario.Size = new System.Drawing.Size(56, 22);
            this.rbtnFiltroCpfFuncionario.TabIndex = 44;
            this.rbtnFiltroCpfFuncionario.TabStop = true;
            this.rbtnFiltroCpfFuncionario.Text = "CPF";
            this.rbtnFiltroCpfFuncionario.UseVisualStyleBackColor = true;
            // 
            // rbtnNomeFuncionario
            // 
            this.rbtnNomeFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rbtnNomeFuncionario.AutoSize = true;
            this.rbtnNomeFuncionario.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.rbtnNomeFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnNomeFuncionario.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rbtnNomeFuncionario.Location = new System.Drawing.Point(330, 414);
            this.rbtnNomeFuncionario.Name = "rbtnNomeFuncionario";
            this.rbtnNomeFuncionario.Size = new System.Drawing.Size(86, 22);
            this.rbtnNomeFuncionario.TabIndex = 43;
            this.rbtnNomeFuncionario.TabStop = true;
            this.rbtnNomeFuncionario.Text = "Matricula";
            this.rbtnNomeFuncionario.UseVisualStyleBackColor = false;
            // 
            // lblFiltroFuncionario
            // 
            this.lblFiltroFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblFiltroFuncionario.AutoSize = true;
            this.lblFiltroFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFiltroFuncionario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblFiltroFuncionario.Location = new System.Drawing.Point(153, 412);
            this.lblFiltroFuncionario.Name = "lblFiltroFuncionario";
            this.lblFiltroFuncionario.Size = new System.Drawing.Size(94, 24);
            this.lblFiltroFuncionario.TabIndex = 42;
            this.lblFiltroFuncionario.Text = "Filtrar por:";
            // 
            // BtnPesquisarFuncionario
            // 
            this.BtnPesquisarFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnPesquisarFuncionario.BackColor = System.Drawing.SystemColors.HighlightText;
            this.BtnPesquisarFuncionario.FlatAppearance.BorderSize = 0;
            this.BtnPesquisarFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPesquisarFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPesquisarFuncionario.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.BtnPesquisarFuncionario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPesquisarFuncionario.Location = new System.Drawing.Point(496, 409);
            this.BtnPesquisarFuncionario.Name = "BtnPesquisarFuncionario";
            this.BtnPesquisarFuncionario.Size = new System.Drawing.Size(86, 35);
            this.BtnPesquisarFuncionario.TabIndex = 40;
            this.BtnPesquisarFuncionario.Text = "Pesquisar";
            this.BtnPesquisarFuncionario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnPesquisarFuncionario.UseVisualStyleBackColor = false;
            // 
            // lblPesFuncionario
            // 
            this.lblPesFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPesFuncionario.AutoSize = true;
            this.lblPesFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesFuncionario.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblPesFuncionario.Location = new System.Drawing.Point(143, 152);
            this.lblPesFuncionario.Name = "lblPesFuncionario";
            this.lblPesFuncionario.Size = new System.Drawing.Size(187, 20);
            this.lblPesFuncionario.TabIndex = 39;
            this.lblPesFuncionario.Text = "Pesquisar Funcionario";
            // 
            // btnExcluFuncionario
            // 
            this.btnExcluFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnExcluFuncionario.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExcluFuncionario.FlatAppearance.BorderSize = 0;
            this.btnExcluFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluFuncionario.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnExcluFuncionario.Location = new System.Drawing.Point(651, 409);
            this.btnExcluFuncionario.Name = "btnExcluFuncionario";
            this.btnExcluFuncionario.Size = new System.Drawing.Size(86, 35);
            this.btnExcluFuncionario.TabIndex = 37;
            this.btnExcluFuncionario.Text = "Excluir";
            this.btnExcluFuncionario.UseVisualStyleBackColor = false;
            // 
            // BtnEditFuncionario
            // 
            this.BtnEditFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BtnEditFuncionario.BackColor = System.Drawing.SystemColors.HighlightText;
            this.BtnEditFuncionario.FlatAppearance.BorderSize = 0;
            this.BtnEditFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEditFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEditFuncionario.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.BtnEditFuncionario.Location = new System.Drawing.Point(573, 409);
            this.BtnEditFuncionario.Name = "BtnEditFuncionario";
            this.BtnEditFuncionario.Size = new System.Drawing.Size(86, 35);
            this.BtnEditFuncionario.TabIndex = 36;
            this.BtnEditFuncionario.Text = "Editar";
            this.BtnEditFuncionario.UseVisualStyleBackColor = false;
            // 
            // DgvFuncionario
            // 
            this.DgvFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.DgvFuncionario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvFuncionario.Location = new System.Drawing.Point(147, 192);
            this.DgvFuncionario.Name = "DgvFuncionario";
            this.DgvFuncionario.RowHeadersWidth = 51;
            this.DgvFuncionario.Size = new System.Drawing.Size(651, 180);
            this.DgvFuncionario.TabIndex = 34;
            // 
            // PanelTitleBar
            // 
            this.PanelTitleBar.BackColor = System.Drawing.SystemColors.Highlight;
            this.PanelTitleBar.Controls.Add(this.lblFun);
            this.PanelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelTitleBar.Location = new System.Drawing.Point(0, 0);
            this.PanelTitleBar.Name = "PanelTitleBar";
            this.PanelTitleBar.Size = new System.Drawing.Size(927, 87);
            this.PanelTitleBar.TabIndex = 85;
            // 
            // lblFun
            // 
            this.lblFun.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblFun.AutoSize = true;
            this.lblFun.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFun.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFun.Location = new System.Drawing.Point(352, 32);
            this.lblFun.Name = "lblFun";
            this.lblFun.Size = new System.Drawing.Size(191, 34);
            this.lblFun.TabIndex = 0;
            this.lblFun.Text = "Cadastrados";
            this.lblFun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(336, 153);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(346, 19);
            this.textBox1.TabIndex = 45;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(336, 173);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(347, 2);
            this.panel1.TabIndex = 46;
            // 
            // radioButton1
            // 
            this.radioButton1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton1.Location = new System.Drawing.Point(263, 414);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(67, 22);
            this.radioButton1.TabIndex = 43;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Nome";
            this.radioButton1.UseVisualStyleBackColor = false;
            // 
            // ListarFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.PanelTitleBar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.rbtnFiltroCpfFuncionario);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.rbtnNomeFuncionario);
            this.Controls.Add(this.lblFiltroFuncionario);
            this.Controls.Add(this.BtnPesquisarFuncionario);
            this.Controls.Add(this.lblPesFuncionario);
            this.Controls.Add(this.btnExcluFuncionario);
            this.Controls.Add(this.BtnEditFuncionario);
            this.Controls.Add(this.DgvFuncionario);
            this.Name = "ListarFuncionario";
            this.Size = new System.Drawing.Size(927, 600);
            ((System.ComponentModel.ISupportInitialize)(this.DgvFuncionario)).EndInit();
            this.PanelTitleBar.ResumeLayout(false);
            this.PanelTitleBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtnFiltroCpfFuncionario;
        private System.Windows.Forms.RadioButton rbtnNomeFuncionario;
        private System.Windows.Forms.Label lblFiltroFuncionario;
        private System.Windows.Forms.Button BtnPesquisarFuncionario;
        private System.Windows.Forms.Label lblPesFuncionario;
        private System.Windows.Forms.Button btnExcluFuncionario;
        private System.Windows.Forms.Button BtnEditFuncionario;
        private System.Windows.Forms.DataGridView DgvFuncionario;
        private System.Windows.Forms.Panel PanelTitleBar;
        private System.Windows.Forms.Label lblFun;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}
